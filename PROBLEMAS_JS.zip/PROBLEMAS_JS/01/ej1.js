var dinero=2;

document.write(dinero);

